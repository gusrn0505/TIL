from torch.utils.data import  DataLoader
import torch.nn.functional as F
import torch

def train(args, model, device, train_dataset, optimizer, epoch) : 
    model.train()
    data_loader = DataLoader(train_dataset, args.batch_size)

    for i, (data, label) in enumerate(data_loader) : 
        data, label = data.to(device), label.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = F.nll_loss(output, label)
        loss.backward() 
        optimizer.step() 

        avg_loss = loss / len(data_loader)
        if i % 100 == 0 : 
            print('Train epoch : {} [{}/{} ({:.0f}%)]\t Loss: {:.4f}'. format(epoch, i, len(data_loader), 100. * i / len(data_loader), avg_loss))
    return model 


def test(args, model, device, test_dataset) : 
    model.eval() 
    test_loss = 0 
    correct = 0 

    data_loader = DataLoader(test_dataset, batch_size = args.batch_size)

    with torch.no_grad() : 
        for (data, label) in data_loader : 
            data, label = data.to(device), label.to(device)

            output = model(data)
            test_loss += F.nll_loss(output, label, reduction='sum').item()
            pred = output.argmax(dim=1, keepdim = True)
            correct += pred.eq(label.view_as(pred)).sum().item()
    
    test_loss /= len(test_dataset)

    print('\n Test set : Average loss : {:.4f}, Accuracy : {}/{} ({:.0f}%) \n'.format(test_loss, correct, len(test_dataset), 100. *correct / len(test_dataset)))

    return correct/len(test_dataset)

