DROPOUT=5
BATCHSIZE=32
EPOCHS=10
LR=0.001
GAMMA=0.1
LOAD=True
DROOT=data/
DATASET=MNIST



python active_CNN_model.py \
--dropout-iterations $DROPOUT \
--batch-size $BATCHSIZE \
--epochs $EPOCHS \
--lr $LR \
--gamma $GAMMA \
--load-data $LOAD \
--dataset-root $DROOT \
--dataset $DATASET