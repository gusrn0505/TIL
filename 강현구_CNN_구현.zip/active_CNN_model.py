import argparse
import pprint
from torchvision import transforms, utils, datasets
from torchvision.transforms import ToTensor
import torch

import torch.optim as optim
from torch.optim.lr_scheduler import StepLR


# 구현 파일 
from CNN_model import MNIST, CIFAR10
from CNN_train_test import train, test

def argparser():
    parser = argparse.ArgumentParser(description='CNN modeling')

    parser.add_argument('--dropout-iterations', type=int, default=5)
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--lr', type=float, default=0.002)
    parser.add_argument('--gamma', type=float, default=0.7)

    parser.add_argument('--load-data', default=True, type=bool)
    parser.add_argument('--dataset-root', default='data/')
    parser.add_argument('--dataset', default='MNIST')
    return parser


if __name__ == "__main__":
    args = argparser().parse_args()
    pprint.pprint(args)

    torch.manual_seed(20)
    device = torch.device("cuda" )
    # use_cuda가 true라면 kwargs를 다음과 같이 지정하기. 
    kwargs = {'num_workers': 1, 'pin_memory': True} 


    PATH = './model_weights/'

    if args.dataset == "MNIST" : 
        train_dataset = datasets.MNIST(root="data",train=True, download=True, transform=ToTensor())
        test_dataset = datasets.MNIST(root="data", train=False, download=True, transform=ToTensor())
        if args.load_data == True : 
            CNN = torch.load(PATH + 'MNIST.pt')
            print("Success to load MNIST model")
        else : CNN = MNIST().to(device)
    
    elif args.dataset == "CIFAR10" : 
        train_dataset = datasets.CIFAR10(root="data",train=True, download=True, transform=ToTensor())
        test_dataset = datasets.CIFAR10(root="data", train=False, download=True, transform=ToTensor())
        if args.load_data == True : 
            CNN = torch.load(PATH + 'CIFAR10.pt')
            print("Success to load CIFAR10 model")

        else : CNN = CIFAR10().to(device)
 
    optimizer = optim.Adam(CNN.parameters(), lr=args.lr)
    scheduler = StepLR(optimizer, step_size = 1, gamma=args.gamma)

    if args.load_data != True : 
        for epoch in range(1, args.epochs +1) : 
            CNN = train(args, CNN, device, train_dataset, optimizer, epoch)
            scheduler.step() 
        torch.save(CNN, PATH + 'new.pt')
    
    accuracy = test(args, CNN, device, test_dataset)

