import torch
from torch import nn
from torch.nn import functional as F

class MNIST(nn.Module) : #(1, 28, 28) -> (16, 12, 12) -> (32, 5, 5)
    def __init__(self) : 
        super(MNIST, self).__init__() 

        self.conv1 = nn.Conv2d(1,16, (5,5))
        self.conv1_normalize = nn.BatchNorm2d(16)
        self.pool1 = nn.MaxPool2d((2,2))

        self.conv2 = nn.Conv2d(16,32, (3,3))
        self.conv2_normalize = nn.BatchNorm2d(32)
        self.pool2 = nn.MaxPool2d((2,2))

        self.drop = nn.Dropout()
        self.fc1 = nn.Linear(800, 32)
        self.fc2 = nn.Linear(32, 10)

    def forward(self,x) : 
        x = self.conv1(x) 
        x = self.conv1_normalize(x) 
        x = F.relu(x)
        x = self.pool1(x) 

        x = self.conv2(x)
        x = self.conv2_normalize(x)
        x = F.relu(x)
        x = self.pool2(x)

        x = self.drop(x)
        x = x.view(-1, 800)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        output = F.log_softmax(x, dim=1)
        return output 



class CIFAR10(nn.Module) : # (3, 32, 32) => (48, 16, 16) => (96, 8, 8) => (192, 4, 4)
    def __init__(self) : 
        super(CIFAR10, self).__init__() 

        self.conv1 = nn.Conv2d(3,48, (3,3), padding=1)
        self.conv1_normalize = nn.BatchNorm2d(48)
        self.pool1 = nn.MaxPool2d((2,2))

        self.conv2 = nn.Conv2d(48,96, (3,3), padding=1)
        self.conv2_normalize = nn.BatchNorm2d(96)
        self.pool2 = nn.MaxPool2d((2,2))

        self.conv3 = nn.Conv2d(96,192, (3,3), padding=1)
        self.conv3_normalize = nn.BatchNorm2d(192)
        self.pool3 = nn.MaxPool2d((2,2))

        self.drop = nn.Dropout()
        self.fc1 = nn.Linear(3072, 64)
        self.fc2 = nn.Linear(64, 10)

    def forward(self,x) : 
        x = self.conv1(x) 
        x = self.conv1_normalize(x) 
        x = F.relu(x)
        x = self.pool1(x) 

        x = self.conv2(x)
        x = self.conv2_normalize(x)
        x = F.relu(x)
        x = self.pool2(x)

        x = self.conv3(x)
        x = self.conv3_normalize(x)
        x = F.relu(x)
        x = self.pool3(x)

        x = self.drop(x)
        x = x.view(-1, 3072)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        output = F.log_softmax(x, dim=1)
        return output