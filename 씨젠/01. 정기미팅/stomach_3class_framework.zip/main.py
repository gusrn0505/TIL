import step2_3class_classifer_tester as step2
import step1_binary_classifier_tester as step1
import project_config as cfg
import os

slide_path = cfg.slide_path

list = os.listdir(slide_path)
list = [i for i in list if ".mrxs" in i]

for slide in list :
    print(slide)
    step1_pred = step1.main_mixpatch(slide)
    if step1_pred == 'N':
        step2.main_feature_cube(slide)
