########Database Connection Configuration Start#################
mariadb = {
    "host": "localhost",
    "user": "root",
    "password": "seegeneai2020",
    "db": "digital_pathology",
}
########Database Connection Configuration Finish################



########Test Configuration Start################################
anatomy="stomach"


date = '20210511'
slide_path = 'f:/ai_solution_test/work_image_files/'+date+'/Stomach/'
result_path = './Stomach_3class/'+date+'/test_result_new/'

################################################################


########Step1 MixPatch##########################################
step1_patch_save_temp_path = './step1_patch_save_temp_path/'
step1_cube_path = './Stomach_3class/'+date+'/step1_feature_cubes/'

step1_lsize = 256
step1_csize = 128

step1_dele_patch_temp = 'True'
step1_batch_size = 128
step1_overlap = 8

step1_patch_level_classifier_archi = 'efficientnet-b3'
step1_slide_level_classifier_archi = 'efficientnet-b3'

step1_patch_model = './test/models/mixpatch/patch_classifier.pth'
step1_slide_model = "./test/models/mixpatch/slide_classifier.pth"
################################################################



########Step2 3classification###################################
step2_patch_save_temp_path = './step2_patch_save_temp_path/'
step2_cube_path = './Stomach_3class/'+date+'/step2_feature_cubes/'

step2_lsize = 256
step2_csize = 128

step2_dele_patch_temp = 'True'
step2_batch_size = 128
step2_overlap = 8

step2_patch_level_classifier_archi = 'efficientnet-b3'
step2_slide_level_classifier_archi = 'efficientnet-b3'

step2_patch_model = './test/models/3class/patch_classifier.pth'
step2_slide_model = "./test/models/3class/slide_classifier.pth"
################################################################