
from openslide import open_slide
from openslide.deepzoom import DeepZoomGenerator
import time, os
import numpy as np
import project_config as cfg

def goodTile(tile):
    tile = np.array(tile)

    h, w, _ = tile.shape
    total_pixels = h * w

    # If the tile is not square
    if h != w:
        return False

    if (tile == tile[0, 0, 0]).all():
        return False

    red = tile[:, :, 0]
    green = tile[:, :, 1]
    blue = tile[:, :, 2]

    t1 = ((red > green) * 1).sum() / total_pixels
    t2 = ((blue > green) * 1).sum() / total_pixels

    if t1 < 0.1 and t2 < 0.1:
        if tile.std(axis=2).mean() < 5:
            return False

    # If the tile has black frames
    right_black = tile[:, -1, :].mean() < 10
    left_black = tile[:, 0, :].mean() < 10
    top_black = tile[0, :, :].mean() < 10
    botton_black = tile[-1, :, :].mean() < 10

    black_frame = right_black or left_black or top_black or botton_black

    if black_frame:
        return False

    # Otherwise, the tile is
    return 'Good'

def openslide_tiling(slide,slide_path, save_path,overlap):

    if not os.path.exists(save_path+slide[:-5]+'/t/'):
        os.makedirs(save_path+slide[:-5]+'/t/')

    slide_ = open_slide(slide_path+slide)
    tiles = DeepZoomGenerator(slide_, tile_size = 256-(overlap*2), overlap = overlap, limit_bounds=True)
    cols, rows = tiles.level_tiles[16]

    for row in range(1,rows-1):
        for col in range(1,cols-1):
            tile = tiles.get_tile(16, (col, row))

            if goodTile(tile) == "Good" :
                tile.save(save_path+slide[:-5]+'/t/'+ str(row) + '_' + str(col) + '.jpg')

    list = os.listdir(save_path + slide[:-5] + '/t/')

    for image in list:
        if os.path.getsize(save_path + slide[:-5] + '/t/'+image) < 5120:
            os.remove(save_path + slide[:-5] + '/t/'+image)

    return cols, rows

def tiling_main(raw_data_path, patch_save_path, dianosis, overlap):
    a = []
    b = []
    for condition in dianosis:
        print(condition)
        slide_path = raw_data_path + condition + "/"
        save_path = patch_save_path + condition + "/"

        list = os.listdir(slide_path)
        list = [i for i in list if ".mrxs" in i]

        for slide in list:
            total_start_time = time.time()
            try:
                c,r = openslide_tiling(slide, slide_path, save_path,overlap)
                a.append(c)
                b.append(r)
                total_time = time.time() - total_start_time
                print('Slide time: {:.2f} min'.format(total_time / (60)))

            except :
                pass


raw_data_path = 'root'
patch_save_path = 'save_root'
dianosis = ['D','M','N']
overlap = 8

type = ['/train/','/test/']
for i in type :
    raw_data_path = raw_data_path+i
    patch_save_path = patch_save_path+i
    tiling_main(raw_data_path, patch_save_path, dianosis,overlap)


