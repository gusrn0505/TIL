import time
import os
import random
import pickle

import torch
import torch.nn as nn
import torch.optim as optim
from efficientnet_pytorch import EfficientNet

import train_config as cfg

torch.cuda.empty_cache()

def data_loader(train_dir,diag):
    data_ = []

    label = 0
    for condition in diag:
        path = train_dir + condition + "/"
        list = os.listdir(path)

        for inputs in list:
            with open(path + inputs, 'rb') as f:
                data = pickle.load(f)

            data_.append([data, label])


        if condition == 'M' or 'U':

            for inputs in list:
                with open(path + inputs, 'rb') as f:
                    data = pickle.load(f)

                data_.append([data, label])

        label += 1

    return data_

def data_suffle(data_,batch_size):
    random.shuffle(data_)

    n = batch_size

    result = [data_[i * n:(i + 1) * n] for i in range((len(data_) + n - 1) // n)]
    dataset = []

    for i in result:
        a = []
        b = []
        for j in range(n):
            try:
                a.append(i[j][0][0])
                b.append(i[j][1])
            except:
                pass
        dataset.append([a, b])

    return dataset


def train(model, num_epochs, batch_size, dirmodel, train_dir, test_dir, lr, diag):
    since = time.time()

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[num_epochs/4,(2*num_epochs)/4,(3*num_epochs)/4], gamma=0.1)

    train_data = data_loader(train_dir, diag)
    test_data = data_loader(test_dir,diag)
    print("data_loaded")

    dataset_test = data_suffle(test_data, int(batch_size / 16))

    for epoch in range(num_epochs):
        dataset_train = data_suffle(train_data, batch_size)

        for param_group in optimizer.param_groups:
            lr = param_group['lr']

        model.train()

        running_corrects = 0.0
        running_loss = 0.0
        test_corrects =0.0

        it = 0.0
        it_t = 0.0

        for inputs, labels in dataset_train:
            inputs = torch.tensor(inputs).float().cuda()
            labels = torch.tensor(labels).long().cuda()

            optimizer.zero_grad()
            outputs = model(inputs)

            loss = criterion(outputs, labels)
            _, preds = torch.max(outputs, 1)

            loss.backward()
            optimizer.step()

            running_corrects += torch.sum(preds == labels).double()
            running_loss += loss.item()
            it += len(inputs)


        torch.save(model.module.state_dict(), dirmodel + str(epoch) + ".pth")


        model.eval()
        for inputs, labels in dataset_test:
            inputs = torch.tensor(inputs).float().cuda()
            labels = torch.tensor(labels).long().cuda()

            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)

            test_corrects += torch.sum(preds == labels).double()
            it_t += len(inputs)


        time_elapsed = time.time() - since
        print('Epoch:{}/{},Ir:{:.4f},loss:{:.4f},train acc:{:.4f},test acc:{:.4f},time {:.0f}m {:.0f}s '.format(epoch,num_epochs - 1,
                                                                                                                lr,
                                                                                                                running_loss / it,
                                                                                                                running_corrects.double() / it,
                                                                                                                test_corrects.double() / it_t,
                                                                                                                time_elapsed // 60,
                                                                                                                time_elapsed % 60))
        scheduler.step()

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))

    return model



torch.cuda.empty_cache()

diag = cfg.diagnosis

model_archi = cfg.slide_level_classifier_archi
slide_model_dir = cfg.slide_model_save_dir

sl = cfg.slide_classifier_sl
epoch = cfg.slide_classifier_epoch
lr = cfg.slide_classifier_lr
dropout =cfg.slide_classifier_dropout
bs =cfg.slide_classifier_bs

train_feature_cube_dir = cfg.feature_cube_dir_train
test_feature_cube_dir = cfg.feature_cube_dir_test

model = EfficientNet.from_name(model_archi, in_channels=2)
model._fc = nn.Linear(model._fc.in_features, 2)
model._dropout = nn.Dropout(dropout)


## Connect model to GPU
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
model.to(device)
if torch.cuda.device_count() > 1:
    model = nn.DataParallel(model).cuda()
    print("multi-gpu")

model = train(model= model,
              num_epochs= epoch,
              batch_size= bs,
              dirmodel= slide_model_dir,
              train_dir = train_feature_cube_dir,
              test_dir = test_feature_cube_dir,
              lr = lr,
              diag = diag)

