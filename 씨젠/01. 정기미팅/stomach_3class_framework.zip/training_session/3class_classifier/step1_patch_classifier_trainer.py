import time

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from efficientnet_pytorch import EfficientNet
from torch.utils.data import Dataset
from torchvision import datasets, transforms
import train_config as cfg

def make_weights_for_balanced_classes(images, nclasses):
    count = [0] * nclasses
    for item in images:
        count[item[1]] += 1
    weight_per_class = [0.] * nclasses
    N = float(sum(count))
    for i in range(nclasses):
        weight_per_class[i] = N / float(count[i])
    weight = [0] * len(images)
    for idx, val in enumerate(images):
        weight[idx] = weight_per_class[val[1]]
    return weight

def data_loader(data_dir, batch_size):
    data_transforms = {
        'train': transforms.Compose([transforms.Resize((256, 256)),
                                     transforms.RandomHorizontalFlip(0.5),
                                     transforms.RandomVerticalFlip(0.5),
                                     transforms.ToTensor(),
                                     transforms.Normalize([0.639, 0.462, 0.735],
                                                          [0.235, 0.243, 0.151])]),

        'test': transforms.Compose([transforms.Resize((256, 256)),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.639, 0.462, 0.735],
                                                         [0.235, 0.243, 0.151])])
    }

    # Create training and validation datasets
    image_datasets = {}
    image_datasets['train'] = datasets.ImageFolder(data_dir + "train/", data_transforms['train'])
    image_datasets['test'] = datasets.ImageFolder(data_dir + "test/", data_transforms['test'])

    weights = make_weights_for_balanced_classes(image_datasets['train'].imgs, len(image_datasets['train'].classes))
    weights = torch.DoubleTensor(weights)
    sampler = torch.utils.data.sampler.WeightedRandomSampler(weights, len(weights))

    dataloaders = {}

    dataloaders['train'] = torch.utils.data.DataLoader(image_datasets['train'],
                                                       batch_size=batch_size,
                                                       sampler=sampler,
                                                       num_workers=0)

    dataloaders['test'] = torch.utils.data.DataLoader(image_datasets['test'],
                                                      batch_size=2,
                                                      shuffle=True,
                                                      num_workers=0)

    print("Data is loaded")

    return dataloaders

def train(model, data, num_epochs, dirmodel, sl, Ir):
    since = time.time()

    best_test_acc = 0.0

    optimizer = optim.Adam(model.parameters(), lr=Ir)
    scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[num_epochs/4, 2*num_epochs/4, 3*num_epochs/4], gamma=0.1)

    for epoch in range(num_epochs):

        ba = 0
        running_loss_train = 0.0
        running_corrects_train = 0.0

        for param_group in optimizer.param_groups:
            lr = param_group['lr']

        print('epoch:{:3d}, lr={:.6f}'.format(epoch, lr))

        model.train()
        for inputs, labels in data["train"]:

            sl_labels = []
            'D,M,N'
            if sl == 'y':
                for i in labels:
                    if i == 0:
                        sl_labels.append([0.7, 0.1, 0.1])
                    if i == 1:
                        sl_labels.append([0.1, 0.7, 0.1])
                    if i == 2:
                        sl_labels.append([0.1, 0.1, 0.7])

            elif sl == 'n':
                for i in labels:
                    if i == 0:
                        sl_labels.append([1., 0., 0.])
                    if i == 1:
                        sl_labels.append([0., 1., 0.])
                    if i == 2:
                        sl_labels.append([0., 0., 1.])

            # training
            labels_new = torch.tensor(sl_labels).cuda()
            inputs = inputs.cuda()

            optimizer.zero_grad()
            outputs = model(inputs)

            loss = F.kl_div(F.log_softmax(outputs), labels_new)

            _, preds = torch.max(outputs, 1)

            running_loss_train += loss.item()
            running_corrects_train += torch.sum(preds == labels.cuda())

            loss.backward()
            optimizer.step()

            running_corrects = torch.sum(preds == labels.cuda()).double() / len(labels)

            if ba % 1000 == 0:
                time_elapsed = time.time() - since
                print('Epoch: {}/{}, batch: {}/{}, loss:{:.4f}, acc:{:.4f}, time {:.0f}m {:.0f}s '.format(epoch,
                                                                                                          num_epochs - 1,
                                                                                                          ba, len(data["train"]),
                                                                                                          loss.item() / len(labels),
                                                                                                          running_corrects.double(),
                                                                                                          time_elapsed // 60,
                                                                                                          time_elapsed % 60))
            ba += 1

        # val
        model.eval()
        running_corrects = 0
        for inputs, labels in data["test"]:
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            cs, preds = torch.max(outputs, 1)
            running_corrects += torch.sum(preds == labels.data)

        epoch_test_acc = running_corrects.double() / len(data["test"].dataset)

        # summary

        epoch_loss_train = running_loss_train / len(data["train"].dataset)
        epoch_acc_train = running_corrects_train.double() / len(data["train"].dataset)

        print('train Loss: {:.4f} running_corrects: {:.4f}'.format(epoch_loss_train, epoch_acc_train))
        print('val corrects: {:.4f} best val corrects: {:.4f}'.format(epoch_test_acc, best_test_acc))

        torch.save(model.module.state_dict(), dirmodel + str(epoch) + ".pth")
        print("A model was saved")

        scheduler.step()

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))


patch_model_save_dir = cfg.patch_model_save_dir
patch_dir = cfg.patch_dir

batch_size_ori = cfg.batch_size
mix_rate = cfg.mix_rate
num_epochs = cfg.num_epochs
mix_condition = cfg.mix_condition
sl = cfg.patch_classifier_sl

patch_level_classifier_archi = cfg.patch_level_classifier_archi

patch_model = EfficientNet.from_name(patch_level_classifier_archi)
patch_model._fc = nn.Linear(patch_model._fc.in_features, 4)

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
if torch.cuda.device_count() > 1:
    patch_model = nn.DataParallel(patch_model).cuda()

patch_model.to(device)


data = data_loader(patch_data, patch_classifier_bs)
train(patch_model,
      data,
      num_epochs=patch_classifier_epoch,
      dirmodel=dirmodel,
      sl=patch_classifier_sl,
      Ir=patch_classifier_lr)
