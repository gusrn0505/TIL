import os
import numpy as np
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F

import torchvision.datasets as dset
import torchvision.transforms as transforms

from torch.utils.data import DataLoader

from efficientnet_pytorch import EfficientNet

import train_config as cfg


class ImageFolderWithPaths(dset.ImageFolder):
    """Custom dataset that includes image file paths. Extends
    torchvision.datasets.ImageFolder
    """

    # override the __getitem__ method. this is the method that dataloader calls
    def __getitem__(self, index):
        # this is what ImageFolder normally returns
        original_tuple = super(ImageFolderWithPaths, self).__getitem__(index)

        # the image file path
        path = self.imgs[index][0]
        terminator = path.index('\\')

        # make a new tuple that includes original and the path
        tuple_with_path = (original_tuple + (str(path)[terminator:],))
        return tuple_with_path

def predict_label(data_path, model1, batch_size):
    trans_params = transforms.Compose([transforms.Resize((512, 512)),
                                     transforms.ToTensor(),
                                     transforms.Normalize([0.639, 0.462, 0.735],
                                                               [0.235, 0.243, 0.151])])

    tile_image = ImageFolderWithPaths(root=data_path, transform=trans_params)
    tile_loader = DataLoader(tile_image, batch_size=batch_size, shuffle=False, num_workers=0)

    a = []
    model1.eval()
    with torch.no_grad():
        for idx, data in enumerate(tile_loader):
            x, _, path = data
            x = x.cuda()
            pred_outputs1 = model1(x)
            pred_outputs1 = F.softmax(pred_outputs1, dim=1)
            _, preds1 = torch.max(pred_outputs1, 1)

            'AB, N'
            for i in range(len(path)):
                if preds1[i] != 1:
                    a.append([path[i], pred_outputs1.cpu().tolist()[i]])

    return a

def base_feature(lsize, csize):
    a = torch.tensor([0.])
    k = torch.tensor([0.])
    for i in range(0, lsize * csize):
        k = torch.cat([k, a], dim=0)
    r = np.reshape(k[1:], (1, lsize, csize))

    a = torch.tensor([0.])
    k = torch.tensor([0.])
    for i in range(0, lsize * csize):
        k = torch.cat([k, a], dim=0)
    g = np.reshape(k[1:], (1, lsize, csize))

    base = torch.cat([r, g], dim=0)

    return np.reshape(base, (1, 2, lsize, csize))

def add_pred_to_based(empty_feature, predict):
    a = []
    # AB,N
    for path, pred in predict:
        terminator = path.index('_')
        col = str(path)[:terminator][1:]
        row = str(path)[terminator + 1:-4]
        a.append([row, col])

        for i in range(2):
            empty_feature[0][i][int(col)][int(row)] = pred[i]

    return empty_feature, a

def extracting_slide_feature(dianosis, model_1, image_path, save_path, lsize, csize, batch_size):

    diag = dianosis
    for condition in diag:

        path = image_path + condition + "/"
        slide_list = os.listdir(path)

        print(condition)
        for slide in slide_list:
            print(slide)
            dir = path + slide + '/'

            try:
                bf = base_feature(lsize, csize)
                predict = predict_label(data_path=dir, model1=model_1, batch_size=batch_size)
                slide_feature, a = add_pred_to_based(bf, predict)

                with open(save_path + condition + "/" + str(slide) + '.txt', 'wb') as f:
                    pickle.dump(slide_feature.tolist(), f)

            except :
                print('No patch')

diagnosis = ['AB','N']

patch_path_train = cfg.patch_in_slide_ori+'train/'
patch_path_test = cfg.patch_in_slide_ori+'test/'
feature_cube_path_train = cfg.feature_cube_dir_train
feature_cube_path_test = cfg.feature_cube_dir_test

lsize = cfg.lsize
csize = cfg.csize
batch_size = 128

model_archi = cfg.patch_level_classifier_archi
patch_classifier = cfg.patch_classiter

model = EfficientNet.from_pretrained(model_archi)
model._fc = nn.Linear(model._fc.in_features, 2)
model.load_state_dict(torch.load(patch_classifier))


device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
if torch.cuda.device_count() > 1:
    model = nn.DataParallel(model).cuda()
    print("multi-gpu")


print('train')
extracting_slide_feature(diagnosis, model, patch_path_train, feature_cube_path_train, lsize, csize, batch_size)

print('test')
extracting_slide_feature(diagnosis, model, patch_path_test, feature_cube_path_test, lsize, csize, batch_size)