
########Test Configuration Start################################
anatomy="stomach"
diagnosis = ['AB','N']
patch_in_slide_ori = 'patch_in_slide_ori'
################################################################



########Step1 MixPatch##########################################

# for patch-level classifier
patch_dir = 'clean_path_dir'
patch_level_classifier_archi = 'efficientnet-b3'
patch_model_save_dir = './models/binary/patch_classifier/'

batch_size = 128
overlap = 8
patch_classifier_sl = 'Y'
num_epochs = 60
mix_rate = 0
mix_condition = 'y'
classifier_lr = 0.01

# for build cube
patch_classiter = 'root'
feature_cube_dir_train = './binary/feature_cubes_train/512_256/train/'
feature_cube_dir_test = './binary/feature_cubes_train/512_256/test/'

lsize = 256
csize = 128

# for slide_level_classifier
slide_level_classifier_archi = 'efficientnet-b3'
slide_model_save_dir = './models/binary/slide_classifier/'

slide_classifier_sl = 'Y'
slide_classifier_epoch = 100
slide_classifier_dropout = 0.01
slide_classifier_bs = 16
slide_classifier_lr = 0.01

################################################################

