import re
import time
import os
import copy

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from collections import OrderedDict
from torch.autograd import Variable
from torchvision import datasets, models, transforms

import numpy as np
import pandas as pd
import random
import train_config as cfg

torch.cuda.empty_cache()

def train(model, data_dir, batch_size_ori, num_epochs, mix_condition, mix_rate, dirmodel, sl):
    since = time.time()

    r = mix_rate / (batch_size_ori + mix_rate)
    w = torch.Tensor([(1 - r) / 2, (1 + r) / 2]).double()
    data, mix = data_loader(data_dir, batch_size_ori, w)

    train_loss_history = []

    optimizer = optim.Adam(model.parameters(), lr=0.1)
    scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[15, 30, 45, 60], gamma=0.1)

    for epoch in range(num_epochs):

        ba = 0
        running_loss_train = 0.0
        running_corrects_train = 0.0

        for param_group in optimizer.param_groups:
            lr = param_group['lr']

        print('epoch:{:3d}, lr={:.6f}'.format(epoch, lr))

        model.train()
        for ori in data["train_s"]:

            # for mix data
            mixing_inputs = []
            mixing_labels = []
            if mix_condition == 'y':
                for i in range(mix_rate):
                    mix_input = []
                    mix_label = []

                    for i in range(4):
                        random_index = random.randrange(0, len(mix))
                        mix_input.append(torch.tensor(mix[random_index][0]))
                        mix_label.append(mix[random_index][1])

                    mix_input = torch.cat((mix_input[0], mix_input[1], mix_input[2], mix_input[3]), dim=1).reshape(
                        (3, 512, 512))
                    mix_input = Variable(mix_input, volatile=True).data
                    mixing_inputs.append(mix_input.tolist())

                    if sum(mix_label) == 0:
                        mixing_labels.append([0.9, 0.1])
                    elif sum(mix_label) == 1:
                        mixing_labels.append([0.4, 0.6])
                    elif sum(mix_label) == 2:
                        mixing_labels.append([0.3, 0.7])
                    elif sum(mix_label) == 3:
                        mixing_labels.append([0.2, 0.8])
                    elif sum(mix_label) == 4:
                        mixing_labels.append([0.1, 0.9])

            # for original data
            resize_input_ori = []
            onehot_labels_ori = []

            for i in ori[0]: resize_input_ori.append(i.data.tolist())

            if sl == 'y':
                for i in ori[1]:
                    if i == 0: onehot_labels_ori.append([0.9, 0.1])
                    if i == 1: onehot_labels_ori.append([0.1, 0.9])
            elif sl == 'n':
                for i in ori[1]:
                    if i == 0: onehot_labels_ori.append([1., 0.])
                    if i == 1: onehot_labels_ori.append([0., 1.])

            # training
            all_inputs = torch.tensor(mixing_inputs + resize_input_ori).cuda()
            all_labels = torch.tensor(mixing_labels + onehot_labels_ori).cuda()

            optimizer.zero_grad()
            outputs = model(all_inputs)
            loss = F.kl_div(F.log_softmax(outputs), all_labels)
            _, preds = torch.max(outputs[:len(onehot_labels_ori)], 1)

            running_loss_train += loss.item() * len(all_labels)

            loss.backward()
            optimizer.step()

            running_corrects = torch.sum(preds == ori[1].cuda())
            running_corrects_train += running_corrects.double()
            running_loss_train += loss.item() * (batch_size_ori + mix_rate)

            if ba % 100 == 0:
                time_elapsed = time.time() - since
                print('Epoch: {}/{}, batch: {}/{}, loss:{:.4f}, acc:{:.4f}, time {:.0f}m {:.0f}s '.format(epoch,
                                                                                                          num_epochs - 1,
                                                                                                          ba, len(
                        data["train_s"]),
                                                                                                          loss.item(),
                                                                                                          running_corrects.double() / batch_size_ori,
                                                                                                          time_elapsed // 60,
                                                                                                          time_elapsed % 60))
            ba += 1

        # val
        model.eval()
        running_corrects = 0
        for inputs, labels in data["test"]:
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            cs, preds = torch.max(outputs, 1)
            running_corrects += torch.sum(preds == labels.data)

        epoch_test_acc = running_corrects.double() / len(data["test"].dataset)

        # summary

        epoch_loss_train = running_loss_train / len(data["train_s"].dataset)
        epoch_acc_train = running_corrects_train.double() / len(data["train_s"].dataset)
        print('train Loss: {:.4f} running_corrects: {:.4f}'.format(epoch_loss_train, epoch_acc_train))
        print('test running_corrects: {:.4f}'.format(epoch_test_acc))

        train_loss_history.append(epoch_loss_train)

        torch.save(model.module.state_dict(), dirmodel + str(epoch) + ".pth")
        print("A model was saved")

        scheduler.step()

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))

    return model, train_loss_history
def data_loader(data_dir, batch_size_ori, w):
    data_transforms = {
        'train': transforms.Compose([transforms.RandomHorizontalFlip(0.5),
                                     transforms.RandomVerticalFlip(0.5),
                                     transforms.Resize(512),
                                     transforms.ToTensor(),
                                     transforms.Normalize([0.639, 0.462, 0.735],
                                                          [0.235, 0.243, 0.151])]),

        'train_mix': transforms.Compose([transforms.RandomHorizontalFlip(0.5),
                                         transforms.RandomVerticalFlip(0.5),
                                         transforms.Resize(256),
                                         transforms.ToTensor(),
                                         transforms.Normalize([0.639, 0.462, 0.735],
                                                              [0.235, 0.243, 0.151])]),

        'val': transforms.Compose([transforms.Resize(512),
                                   transforms.ToTensor(),
                                   transforms.Normalize([0.639, 0.462, 0.735],
                                                        [0.235, 0.243, 0.151])])
    }

    # Create training and validation datasets
    image_datasets = {}
    image_datasets['train_mini'] = datasets.ImageFolder(data_dir + "train_mix/", data_transforms['train_mix'])
    image_datasets['train'] = datasets.ImageFolder(data_dir + "train/", data_transforms['train'])
    image_datasets['test'] = datasets.ImageFolder(data_dir + "test/", data_transforms['test'])

    al = len(image_datasets['train'])
    file_list = os.listdir('./data/sampling_data_binary/train/0normal')
    n = len(file_list)
    w = np.concatenate((np.full(n, w[0]), np.full(al - n, w[0])))
    sampler = torch.utils.data.sampler.WeightedRandomSampler(w, len(image_datasets['train']))

    dataloaders = {}

    dataloaders['train_s'] = torch.utils.data.DataLoader(image_datasets['train'],
                                                         batch_size=batch_size_ori,
                                                         sampler=sampler,
                                                         num_workers=8)
    dataloaders['test'] = torch.utils.data.DataLoader(image_datasets['test'],
                                                      batch_size=int(batch_size_ori / 10),
                                                      shuffle=True, num_workers=8)

    print("Data is loaded")

    return dataloaders, image_datasets['train_mixing']


patch_model_save_dir = cfg.patch_model_save_dir
patch_dir = cfg.patch_dir

batch_size_ori = cfg.batch_size
mix_rate = cfg.mix_rate
num_epochs = cfg.num_epochs
mix_condition = cfg.mix_condition
sl = cfg.patch_classifier_sl

patch_level_classifier_archi = cfg.patch_level_classifier_archi

patch_model = EfficientNet.from_name(patch_level_classifier_archi)
patch_model._fc = nn.Linear(patch_model._fc.in_features, 2)

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
if torch.cuda.device_count() > 1:
    patch_model = nn.DataParallel(patch_model).cuda()
patch_model.to(device)

model,  hist_train_loss  = train(patch_model,
                                 patch_dir,
                                 batch_size_ori,
                                 num_epochs= num_epochs,
                                 mix_condition = mix_condition,
                                 mix_rate = mix_rate,
                                 dirmodel = patch_model_save_dir,
                                 sl =sl )
