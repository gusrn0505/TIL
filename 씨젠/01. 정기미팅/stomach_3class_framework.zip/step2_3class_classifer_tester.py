import csv
import os
import pickle
import shutil
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.datasets as dset
import torchvision.transforms as transforms
from efficientnet_pytorch import EfficientNet
from openslide import open_slide
from openslide.deepzoom import DeepZoomGenerator
from torch.utils.data import DataLoader
from torchvision.utils import save_image

import project_config as cfg


def patch_model(patch_model_path):
    patch_model = EfficientNet.from_name(patch_level_classifier_archi)
    patch_model._fc = nn.Linear(patch_model._fc.in_features, 3)

    patch_model.load_state_dict(torch.load(patch_model_path))
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    if torch.cuda.device_count() > 1:
        patch_model = nn.DataParallel(patch_model).cuda()
    patch_model.to(device)

    return patch_model

def slide_model(slide_model_path):
    slide_model = EfficientNet.from_name(slide_level_classifier_archi, in_channels=3)
    slide_model._fc = nn.Linear(slide_model._fc.in_features, 3)

    slide_model.load_state_dict(torch.load(slide_model_path))
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    if torch.cuda.device_count() > 1:
        slide_model = nn.DataParallel(slide_model).cuda()
    slide_model.to(device)

    return slide_model

def goodTile(tile):
    tile = np.array(tile)
    h, w, _ = tile.shape
    total_pixels = h * w

    # If the tile is not square
    if h != w:
        return False

    # If the tile is white (or, all the pixels are same)
    if (tile == tile[0, 0, 0]).all():
        return False

    # If the green channel is more salient than the red or blue channel (normal tile is purple,
    # so the red and blue are more salient)
    red = tile[:, :, 0]
    green = tile[:, :, 1]
    blue = tile[:, :, 2]

    t1 = ((red > green) * 1).sum() / total_pixels
    t2 = ((blue > green) * 1).sum() / total_pixels

    if t1 < 0.1 and t2 < 0.1:
        if tile.std(axis=2).mean() < 5:
            return False

    # If the tile has black frames

    right_black = tile[:, -1, :].mean() < 10
    left_black = tile[:, 0, :].mean() < 10
    top_black = tile[0, :, :].mean() < 10
    botton_black = tile[-1, :, :].mean() < 10

    black_frame = right_black or left_black or top_black or botton_black

    if black_frame:
        return False

    # Otherwise, the tile is
    return 'Good'

def openslide_tiling(slide, slide_path, patch_save_path,overlap):

    if not os.path.exists(patch_save_path+slide[:-5]+'/t/'):
        os.makedirs(patch_save_path+slide[:-5]+'/t/')


    slide_ = open_slide(slide_path+slide)
    tiles = DeepZoomGenerator(slide_, tile_size = 256-(overlap*2), overlap = overlap,limit_bounds=True)
    cols, rows = tiles.level_tiles[16]
    slide_width, slide_height = tiles.level_dimensions[16]

    for row in range(1,rows-1):
        for col in range(1,cols-1):
            tile = tiles.get_tile(16, (col, row))

            if goodTile(tile) == "Good" :
                tile.save(patch_save_path+slide[:-5]+'/t/'+str(row)+'_'+str(col)+'.jpg')

    # Patches under 10KB are removed, noise
    list = os.listdir(patch_save_path + slide[:-5]+'/t/')
    for image in list:
        if os.path.getsize(patch_save_path + slide[:-5]+'/t/'+image) < 5120:
            os.remove(patch_save_path + slide[:-5]+'/t/' +image)

    return slide_width, slide_height

class ImageFolderWithPaths(dset.ImageFolder):
    """Custom dataset that includes image file paths. Extends
    torchvision.datasets.ImageFolder
    """

    # override the __getitem__ method. this is the method that dataloader calls
    def __getitem__(self, index):
        # this is what ImageFolder normally returns
        original_tuple = super(ImageFolderWithPaths, self).__getitem__(index)

        # the image file path
        path = self.imgs[index][0]
        terminator = path.index('\\')

        # make a new tuple that includes original and the path
        tuple_with_path = (original_tuple + (str(path)[terminator:],))
        return tuple_with_path


def base_feature(lsize, csize):
    a = torch.tensor([0.])
    k = torch.tensor([0.])
    for i in range(0, lsize * csize):
        k = torch.cat([k, a], dim=0)
    r = np.reshape(k[1:], (1, lsize, csize))

    a = torch.tensor([0.])
    k = torch.tensor([0.])
    for i in range(0, lsize * csize):
        k = torch.cat([k, a], dim=0)
    g = np.reshape(k[1:], (1, lsize, csize))

    a = torch.tensor([0.])
    k = torch.tensor([0.])
    for i in range(0, lsize * csize):
        k = torch.cat([k, a], dim=0)
    b = np.reshape(k[1:], (1, lsize, csize))

    base = torch.cat([r, g, b], dim=0)

    return np.reshape(base, (1, 3, lsize, csize))


def add_pred_to_based(empty_feature, predict,overlap):
    patch_pred = []
    # D M N U
    # informatio of each patch location is in the file name
    for path, pred, pred_label in predict:
        terminator = path.index('_')
        col = str(path)[:terminator][1:]
        row = str(path)[terminator + 1:-4]

        #put in prediction info at the base feature-cube
        for i in range(3):
            empty_feature[0][i][int(col)][int(row)] = pred[i]

        # it is for a heatmap
        patch_pred.append([(int(row)-1)*(256-(overlap*2)),(int(col)-1)*(256-(overlap*2)), pred_label])

    return empty_feature, patch_pred



def predict_label(patch_save_path, slide, patch_model1, batch_size):
    patch_level_pred = []

    # location of patch_images
    patch_image_path = patch_save_path+slide[:-5]+'/'

    #load dataset
    trans_params = transforms.Compose([transforms.Resize((256, 256)),
                                       transforms.ToTensor(),
                                       transforms.Normalize([0.639, 0.462, 0.735],
                                                            [0.235, 0.243, 0.151])])

    tile_image = ImageFolderWithPaths(root=patch_image_path, transform=trans_params)
    tile_loader = DataLoader(tile_image, batch_size=batch_size, shuffle=False, num_workers=0)

    #patch-level classification
    patch_model1.eval()
    with torch.no_grad():
        for idx, data in enumerate(tile_loader):
            x, _, path = data
            x = x.cuda()
            pred_outputs1 = patch_model1(x)
            pred_outputs1 = F.softmax(pred_outputs1, dim=1)
            _, preds1 = torch.max(pred_outputs1, 1)

            'd,m,n,u'
            for i in range(len(path)):
                # Normal patch considering as nothing
                if preds1[i] != 2:
                    patch_level_pred.append([path[i], pred_outputs1.cpu().tolist()[i], preds1.cpu().tolist()[i]])

    return patch_level_pred


def build_feature_cube(patch_model1, slide, patch_save_path, cube_path,jpg_path, lsize, csize, overlap, batch_size):

    if not os.path.exists(cube_path):
        os.makedirs(cube_path)

    if not os.path.exists(jpg_path):
        os.makedirs(jpg_path)


    # build base feature-cube
    bf = base_feature(lsize,csize)

    # patch-level classification
    patch_level_pred = predict_label(patch_save_path, slide, patch_model1, batch_size)

    # build feature-cube using base cube and result of patch-level classification
    slide_feature, patch_pred = add_pred_to_based(bf, patch_level_pred, overlap)

    save_image(slide_feature[0], jpg_path + "/" + str(slide) + '.jpg')

    # save feature-cube
    with open(cube_path + str(slide[:-5]) + '.txt', 'wb') as f:
        pickle.dump(slide_feature.tolist(),f)


    return patch_pred


def test(model, cube_path, slide):

    #load a feature-cube
    with open(cube_path + str(slide[:-5]) + '.txt', 'rb') as f:
        data = pickle.load(f)

    model.eval()
    inputs = torch.tensor(data).float().cuda()
    outputs = model(inputs)
    _, preds = torch.max(outputs, 1)

    # D M N
    if preds.item() ==0 :
        pred = 'D'
    if preds.item() ==1 :
        pred = 'M'
    if preds.item() ==2 :
        pred = 'N'

    return pred


def main(anatomy, slide_path, patch_save_path, patch_model1,slide_model1, cube_path,
         result_path, overlap ,lsize, csize, batch_size, dele_temp):

    total_start_time = time.time()
    try :
        #tiling
        slide_width, slide_height = openslide_tiling(slide, slide_path, patch_save_path,overlap)
        patch_pred = build_feature_cube(patch_model1, slide, patch_save_path, cube_path, jpg_path,
                                            lsize, csize, overlap, batch_size)
        pred = test(slide_model1, cube_path, slide)


        a = []
        for i in range(len(patch_pred)) :
            # D M N U
            if patch_pred[i][2] == 0:
                pred_p = 'D'
            if patch_pred[i][2] == 1:
                pred_p = 'M'
            if patch_pred[i][2] == 2:
                pred_p = 'N'

            a.append([slide[:-5], anatomy, slide_width, slide_height, patch_pred[i][0],patch_pred[i][1],pred_p,pred])


        # save results
        if not os.path.exists(result_path):
            os.makedirs(result_path)

        with open(result_path + pred+'_'+slide[:-5]+ ".csv", 'w', newline= '') as f :
            writer = csv.writer(f)
            writer.writerow(['Slide','anatomy','x_scale','y_scale','x_loc','y_loc','patch_label','slide_label'])
            writer.writerows(a)
    except :
        print('No patch')
    total_time = time.time() - total_start_time
    print('step2_time: {:.2f} min'.format(total_time / (60)))

    if dele_temp == 'True' :
        shutil.rmtree(patch_save_path+slide[:-5])

    return pred_p




def main_fc(slide) :
    anatomy = cfg.anatomy

    patch_model_path = cfg.step2_patch_model
    slide_model_path = cfg.step2_slide_model
    patch_level_classifier_archi = cfg.step2_patch_level_classifier_archi
    slide_level_classifier_archi = cfg.step2_slide_level_classifier_archi

    lsize = cfg.step2_lsize
    csize = cfg.step2_csize

    batch_size = cfg.step2_batch_size
    overlap = cfg.step2_overlap

    patch_save_path = cfg.step2_patch_save_temp_path
    cube_path = cfg.step2_cube_path
    result_path = cfg.step2_result_path

    dele_temp = cfg.step2_dele_patch_temp


    patch_model1 = patch_model(patch_model_path, patch_level_classifier_archi)
    slide_model1 = slide_model(slide_model_path, slide_level_classifier_archi)

    pred = main(anatomy,
                slide_path,
                patch_save_path,
                patch_model1,
                slide_model1,
                cube_path,
                result_path,
                overlap,
                lsize,
                csize,
                batch_size,
                dele_temp)

    return pred


